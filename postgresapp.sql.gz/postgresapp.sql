--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE "fweissi";
ALTER ROLE "fweissi" WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS;






--
-- Database creation
--

REVOKE CONNECT,TEMPORARY ON DATABASE "template1" FROM PUBLIC;
GRANT CONNECT ON DATABASE "template1" TO PUBLIC;
CREATE DATABASE "watchdogssignup" WITH TEMPLATE = template0 OWNER = "fweissi";


\connect "postgres"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: postgres; Type: COMMENT; Schema: -; Owner: fweissi
--

COMMENT ON DATABASE "postgres" IS 'default administrative connection database';


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: fweissi
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


--
-- PostgreSQL database dump complete
--

\connect "template1"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: template1; Type: COMMENT; Schema: -; Owner: fweissi
--

COMMENT ON DATABASE "template1" IS 'default template for new databases';


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: fweissi
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


--
-- PostgreSQL database dump complete
--

\connect "watchdogssignup"

SET default_transaction_read_only = off;

--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: fweissi
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS "plpgsql" WITH SCHEMA "pg_catalog";


--
-- Name: EXTENSION "plpgsql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "plpgsql" IS 'PL/pgSQL procedural language';


SET search_path = "public", pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: fluent; Type: TABLE; Schema: public; Owner: fweissi
--

CREATE TABLE "fluent" (
    "id" integer NOT NULL,
    "name" character varying(255) NOT NULL
);


ALTER TABLE "fluent" OWNER TO "fweissi";

--
-- Name: fluent_id_seq; Type: SEQUENCE; Schema: public; Owner: fweissi
--

CREATE SEQUENCE "fluent_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "fluent_id_seq" OWNER TO "fweissi";

--
-- Name: fluent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fweissi
--

ALTER SEQUENCE "fluent_id_seq" OWNED BY "fluent"."id";


--
-- Name: members; Type: TABLE; Schema: public; Owner: fweissi
--

CREATE TABLE "members" (
    "id" integer NOT NULL,
    "name" character varying(255) NOT NULL,
    "email" character varying(255) NOT NULL
);


ALTER TABLE "members" OWNER TO "fweissi";

--
-- Name: members_id_seq; Type: SEQUENCE; Schema: public; Owner: fweissi
--

CREATE SEQUENCE "members_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "members_id_seq" OWNER TO "fweissi";

--
-- Name: members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fweissi
--

ALTER SEQUENCE "members_id_seq" OWNED BY "members"."id";


--
-- Name: posts; Type: TABLE; Schema: public; Owner: fweissi
--

CREATE TABLE "posts" (
    "id" integer NOT NULL,
    "content" character varying(255) NOT NULL
);


ALTER TABLE "posts" OWNER TO "fweissi";

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: fweissi
--

CREATE SEQUENCE "posts_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "posts_id_seq" OWNER TO "fweissi";

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fweissi
--

ALTER SEQUENCE "posts_id_seq" OWNED BY "posts"."id";


--
-- Name: fluent id; Type: DEFAULT; Schema: public; Owner: fweissi
--

ALTER TABLE ONLY "fluent" ALTER COLUMN "id" SET DEFAULT "nextval"('"fluent_id_seq"'::"regclass");


--
-- Name: members id; Type: DEFAULT; Schema: public; Owner: fweissi
--

ALTER TABLE ONLY "members" ALTER COLUMN "id" SET DEFAULT "nextval"('"members_id_seq"'::"regclass");


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: fweissi
--

ALTER TABLE ONLY "posts" ALTER COLUMN "id" SET DEFAULT "nextval"('"posts_id_seq"'::"regclass");


--
-- Data for Name: fluent; Type: TABLE DATA; Schema: public; Owner: fweissi
--

COPY "fluent" ("id", "name") FROM stdin;
1	Member
2	Post
\.


--
-- Name: fluent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fweissi
--

SELECT pg_catalog.setval('"fluent_id_seq"', 2, true);


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: fweissi
--

COPY "members" ("id", "name", "email") FROM stdin;
1	Keith Weiss	keith@doubleencore.com
\.


--
-- Name: members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fweissi
--

SELECT pg_catalog.setval('"members_id_seq"', 6, true);


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: fweissi
--

COPY "posts" ("id", "content") FROM stdin;
\.


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fweissi
--

SELECT pg_catalog.setval('"posts_id_seq"', 1, false);


--
-- Name: fluent fluent_pkey; Type: CONSTRAINT; Schema: public; Owner: fweissi
--

ALTER TABLE ONLY "fluent"
    ADD CONSTRAINT "fluent_pkey" PRIMARY KEY ("id");


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: fweissi
--

ALTER TABLE ONLY "members"
    ADD CONSTRAINT "members_pkey" PRIMARY KEY ("id");


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: fweissi
--

ALTER TABLE ONLY "posts"
    ADD CONSTRAINT "posts_pkey" PRIMARY KEY ("id");


--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--

